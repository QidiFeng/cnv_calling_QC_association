from sys import stderr
from sys import stdout
from sys import exit

'''
A small class wrap the check return values of running command,
and print out the values
'''

class MyLog:
        def __init__ (self, outfile='/dev/stdout', errfile='/dev/stderr'):
		self.log_stdout_file = outfile
		self.log_stderr_file = errfile

		if outfile == '/dev/stdout':
			self.log_stdout_f=stdout
		else:
                	self.log_stdout_f = open (outfile, 'w')


		if errfile == '/dev/stderr':
			self.log_stdout_f=stderr
		else:
                	self.log_stderr_f = open (errfile, 'w')
	# ------------------------------------------------------------------ |

        def check_log (self, retval, step, outmsg=None, errmsg=None):
		if retval == 0 or retval is None:
		    print >> stderr, step, 'finished SUCCESSFULLY.'
		    print >> self.log_stdout_f, step, 'finished SUCCESSFULLY.'
		else:
		    print >> stderr, step, 'FAILED.'  # write to stderr
		    print >> self.log_stderr_f, step, 'FAILED.'  # write to log

		    if errmsg is not None: 
			    print >> self.log_stderr_f, \
			      '============================================\n',\
			      'Message from stderr:'
			    print >> self.log_stderr_f, errmsg

			    print >> self.log_stdout_f, \
				'============================================',\
				'Message from stdout:'
			    print >> self.log_stderr_f, outmsg


		    if outmsg is not None:
			    print >> self.log_stdout_f, \
				'============================================'
			    print >> self.log_stdout_f, outmsg

			    print >> stdout, \
				'============================================'
			    print >> stdout, outmsg

		    # when a list is given, assuming they are file names
		    if type(retval).__name__ == 'list':
			    print >> self.log_stderr_f, step, \
						'FAILED, check these files:'
			    print >> self.log_stderr_f, '\n'.join (retval)

		    print >> stderr,'PLEASE CHECK', self.log_stderr_file, \
					'and', self.log_stdout_file, \
					'FOR MORE INFORMATION.'
		    exit(1)
	# ------------------------------------------------------------------ |

	def print_err (self, msg):
		'''
		print out message to both standard output 
		and the specified place
		'''
		print >> stderr, msg
		print >> self.log_stderr_f, msg
	# ------------------------------------------------------------------ |

	def print_out (self, msg):
		'''
		print out message to both standard output 
		and the specified place
		'''
		print >> stderr, msg
		print >> self.log_stdout_f, msg
	# ------------------------------------------------------------------ |

	def __del__ (self):
		self.log_stdout_f.close()
		self.log_stderr_f.close()
	# ------------------------------------------------------------------ |
