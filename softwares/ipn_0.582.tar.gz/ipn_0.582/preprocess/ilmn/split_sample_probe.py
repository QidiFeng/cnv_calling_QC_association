#! /usr/bin/python

'''
THIS SCRIPT SERVES FOR TWO PURPOSES
* grab each sample's probe intensity information
* grab probe information

NOTE: the two tasks are finished mutually.
'''

import os, re, sys
import ipn_util
import myprobe
import IpnFormat

file_list   = None
input_file  = None
dest_dir    = None
sample_file = None
suffix      = None

def get_file_name (cur_nm):
    return os.path.join (dest_dir, cur_nm+'.'+suffix)
# ---------------------------------------------------------------- |

def write_line (outf, line):
    out = ipn.format_line(line)

    if out is None: return

    print >> outf, out
# ---------------------------------------------------------------- |

def form_probe_line (E):
    if ipn.chr is None: 
	if ipn.all_probes.has_key (E[ipn.snp_name]):
	    return ipn.all_probes[E[ipn.snp_name]]
        else: return None

    if ipn.all_probes is not None:
	if ipn.all_probes.has_key (E[ipn.snp_name]):
		return myprobe.Probe (E[ipn.snp_name], 
				E[ipn.chr], E[ipn.position])
	else: return None
    
    return myprobe.Probe (E[ipn.snp_name], E[ipn.chr], E[ipn.position])
# ---------------------------------------------------------------- |

def read_probe (fname):
    h = { }

    f = open (fname)
    for line in f:
	E = line.rstrip ('\n').split()

	if h.has_key (E[0]): 
	    print >> sys.stderr, E[0], 'is duplicated.'
	    print >> sys.stderr, "OLD=", h[E[0]].get_line()
	    print >> sys.stderr, line,
	    continue

	h[E[0]] = myprobe.Probe(E[0], E[1], E[2])

    f.close()

    print >> sys.stderr, 'Total interested probe =', len(h)

    return h
# ---------------------------------------------------------------- |

def write_init ( E, sample_list ):
    cur_nm = E[ipn.sample_id]

    print >> sys.stderr, cur_nm

    cur_fname = get_file_name(cur_nm)

    cur_f = open (cur_fname, 'w')

    sample_list.append (cur_nm)

    return cur_nm, cur_fname, cur_f
# ---------------------------------------------------------------- |

# split the file
def do_split ( fname, sample_list ):
    inf = open ( fname )

    first_line = inf.readline()

    if ( re.search ('\[Header\]', first_line) ):
	while True:
	    line = inf.readline()

	    if ( line == '' ): break

	    # reached the header line, check headers
	    if ( re.search ('Sample ID', line) ): break

    first_line = inf.readline ()

    first_line = first_line.rstrip ( '\n' )
    first_line = first_line.rstrip ( '\r' )

    #E = first_line.split(',')
    E = ipn.split(first_line)

    cur_nm, cur_fname, cur_f = write_init ( E, sample_list )
    write_line   (cur_f, E)

    while True:
        line = inf.readline()

        if ( line == '' ): break

	E = ipn.split (line)

        if ( E[ipn.sample_id] != cur_nm ):
            cur_f.close()
            cur_nm, cur_fname, cur_f = write_init ( E, sample_list )

        write_line ( cur_f, E )

    cur_f.close()
    inf.close()
# --------------------------------------------------------------- |

def split_samples ( data_list ):
    sample_list = [ ]

    for afile in data_list:
	print >> sys.stderr, 'splitting', afile
	if ( os.path.exists(afile) ):
	    do_split ( afile, sample_list )
	else:
	    print >> sys.stderr, afile, ' does not exist.'

    if ( sample_file is not None ):
        f = open ( sample_file, 'w' )
        for nm in sample_list:
            print >> f, nm
        f.close()
# -------------------------------------------------------------------|

# Here we assume that the probe information is in the file
def find_all_probes (fname, outfile):
    if ( not os.path.exists(fname) ):
	print >> sys.stderr, outfile, 'does NOT exist.'
	sys.exit(1)

    allprobes = [ ]

    inf =  open ( fname )

    first_line = inf.readline()

    if ( re.search ('\[Header\]', first_line) ):
        while True:
            line = inf.readline()

            if ( line == '' ): break

	    # reached the header line, check headers
            if ( re.search ( 'Sample ID', line) ): break

        first_line = inf.readline ()

    E = ipn.split(first_line)
    cur_nm = E[ipn.sample_id]

    allprobes.append ( form_probe_line(E) )

    while True:
        line = inf.readline()

        if ( line == '' ): break

	E = ipn.split (line)

	# we check one sample
        if ( E[ipn.sample_id] != cur_nm ): break

        allprobes.append (form_probe_line(E))
    inf.close()

    outf = open (outfile, 'w')
    for a in allprobes:
	if a is None: continue
	print >> outf, a.getline()
    outf.close()
# ------------------------------------------------------------------ |


#
#
# main starts from here
from optparse import OptionParser

parser = OptionParser()

parser.add_option ( '-f', '--file-list', dest='filelist',
        help='A file contains all the file names we need to split' )

parser.add_option ( '-i', '--input-file', dest='infile',
        help='A file that we need to split, when -f is specified, this option is ignored' )

parser.add_option ( '-d', '--destination-dir', dest='destdir',
        help='Output directory' )

parser.add_option ( '-x', '--file-suffix', dest='suffix',
        help='File suffix to each sample' )

parser.add_option ( '-m', '--sample-name', dest='sample_name',
        help='Output file contains all the sample names.' )

parser.add_option ( '-p', '--probe-file', dest='probefile',
	help='Probe file used to generate probe coordinates' )

parser.add_option ( '-b', '--generate-probe', dest='outprobe',
	help='Output probe files, in the format id, chr, pos' )

options, args = parser.parse_args()

if ( len(sys.argv) == 1 ):
        parser.print_help ()
        sys.exit(1)

# all_probes serves for two purposes: 
# either used for annotating the probes, or selecting certain probes
all_probes = None
if ( options.probefile ):
	all_probes = read_probe (options.probefile)

if ( not (options.filelist) and not (options.infile) ):
	ipn_util.error ( "No input files, one of -f and -i must be specified." )

if ( options.filelist and options.infile ):
        ipn_util.error ( 'You need to use only one of -f and -i.' )

if ( (not options.destdir) and (not options.outprobe) ):
	ipn_util.error ( "Please specify destination directory or output probe file." )

if ( (not options.suffix) and (not options.outprobe) ):
	ipn_util.error ("Please specify output suffix for each file.")

if ( options.filelist ):
	file_list  = options.filelist

if ( options.infile ):
	input_file = options.infile

sample_file = options.sample_name
dest_dir = options.destdir
suffix   = options.suffix

all_files = [ ]
if ( file_list is None ):
        all_files.append ( input_file )
else:
	f = open ( file_list )
	for line in f:
	    if line[0] == '#': continue
	    all_files.append ( line.rstrip ('\n') )
	f.close()

outprobe = options.outprobe

ipn=IpnFormat.IPNFormat (all_files[0], all_probes)

if not outprobe:
	ipn_util.check_or_make_dir ( dest_dir )
	split_samples ( all_files )
else:
	find_all_probes (all_files[0], outprobe)
