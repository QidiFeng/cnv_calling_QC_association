'''
Some general functions used by ipattern preprocessing scripts. Mainly,
the functions reflect the ipattern code directory structure.
'''

import os
import re 
import sys
import copy

mergedir='results'
proj_name_env='PROJNAME'
ipnbase='IPNBASE'
Rerr='Rerr'
Rout='Rout'
apt_cmd="apt-probeset-summarize"
R_cmd=None

class NoCommand (Exception): 
	def __init__(self, paths, lookup_cmd):
		self.paths=paths
		self.lookup_cmd=lookup_cmd

	def __str__(self):
		return "Command %s is NOT found in %s." % \
				(self.lookup_cmd, self.paths)
# -------------------------------------------------------------------------- |

def error (msg, where=sys.stderr):
	print >> where, msg
	sys.exit(1)
# -------------------------------------------------------------------------- |

def check_file ( filename ):
	if not os.path.exists (filename):
		error ( "File '%s' does NOT exist." % (filename) )
# -------------------------------------------------------------------------- |

# given a command, search it in the PATH environment variable
def get_command (cmd):
	all_paths=os.getenv ('PATH')

	for path in all_paths.split (":"):
		thecmd=os.path.join(path, cmd)
		if os.path.exists(thecmd): 
			return thecmd

	raise NoCommand (all_paths, cmd)
# -------------------------------------------------------------------------- |

def get_R_interpreter ():
	# first time do not look for R interpreter
	#if R_cmd is not None : return R_cmd

	R_cmd=get_command ('R')

	return R_cmd
# ---------------------------------------------------------------------------|

def get_mysep(): 
	return '___'
# -------------------------------------------------------------------------- |

def get_project_name ():
	return os.getenv (proj_name_env)
# -------------------------------------------------------------------------- |

# use a directory name, 
def make_ipn_call_file (dirname, sig):
	return os.path.join (mergedir, 
			     sig+'_all_calls.txt')
			     #os.path.basename(dirname)+'_all_calls.txt')
# -------------------------------------------------------------------------- |

def get_ipn_base ():
	path=os.getenv('IPNBASE')

	if path is None:
		error ('Please setup environment variable "IPNBASE"')

	return path
# -------------------------------------------------------------------------- |

def get_pqfile ():
	ipn_base=get_ipn_base ()

	pqpath=os.path.join (ipn_base, 'preprocess/ref_files')
	pqfile=os.path.join (pqpath,   'pq.txt')

	if not os.path.exists (pqfile):
		error ( "pqfile " + pqfile + " does not exist." )

	return pqfile
# ---------------------------------------------------------------------------|

# directory store all the log information
def get_log_dir ():
	return os.path.join (get_ipn_base(), 'log')
# ---------------------------------------------------------------------------|

def get_ipn_Rcode_dir ():
	return os.path.join (get_ipn_base(), 'preprocess/common/Rcode')
# ---------------------------------------------------------------------------|

def get_log_file ():
	return os.path.join (get_log_dir(), 'commands_history.txt')
# ---------------------------------------------------------------------------|

def get_result_dir ( ):
    ''' When ipattern CNV calling finishes, then final calling file will be 
        stored in this directory.'''
    return mergedir
# -------------------------------------------------------------------------- |

# get the directory name of the affymetrix preprocessing pipeline 
def get_affy_path ( cmd ):
        cmd_path = os.path.join (get_ipn_base(), 'preprocess/affy')
        return os.path.join (cmd_path, cmd)
# ----------------------------------------------------------------------- |

# get the directory name of the illumina preprocessing pipeline 
def get_ilmn_path ( cmd ):
        cmd_path = os.path.join (get_ipn_base(), 'preprocess/ilmn')
        return os.path.join (cmd_path, cmd)
# ----------------------------------------------------------------------- |

def get_ipn_path ( ):
        return os.path.join (get_ipn_base(), 'ipn')
# ----------------------------------------------------------------------- |

def change_name ( old_name ):
    '''
    Change old name: if the old name starts with X or numbers, 
    prepend an X also change every '-' in the name to '_'. 
    '''
    # create new name
    new_name = copy.deepcopy ( old_name )

    if ( re.search ( '[^A-Za-z0-9_\.]', old_name ) ):
        new_name = re.sub ( '[^A-Za-z0-9_\.]', '.', new_name )

    if ( re.search ( '^[0-9|X]', old_name ) ):
        new_name = 'X'+new_name

    return new_name
# ------------------------------------------------------------------- |

def read_sample_file ( fname, create_hash = True ):
    '''
    Given a file name, which contains a sample name a line,
    we create either a sample name list or sample hash table, 
    and return it.
    '''

    name_list = [ ]

    f = open ( fname )
    for line in f:
	# ignore the commentary lines
	if ( line[0] == '#' ): continue
        name_list.append ( line.rstrip ( '\n' ) )
    f.close()

    if ( not create_hash ):
        return name_list
    else:
        h = { }
        for aname in name_list:
            h[aname] = aname
        return h
# ------------------------------------------------------------------- |

def write_sample_file ( fname, sample_list ):
    '''
    Given a file name, write the given sample list to the file,
    one sample per line. 
    '''

    f = open (fname, 'w')
    print >> f, '\n'.join (sample_list)
    f.close()
# ------------------------------------------------------------------- |


# iPattern output file headers
class ipn_header:
    names = ['CNV_type',
	     'chr'
	     'start'
	     'end'
	     'probe#'
	     'on_probe#'
	     'clusterIdx'
	     'gain_/loss_score'
	     'cluster_score'
	     'gain_/loss_sample#'
	     'sample_score'
	     'sample_ID'
	     'CNV_event_ID'
	     'CNVR_ID']

    h = {'CNV_type':0,
	 'chr':1,
	 'start':2,
	 'end':3,
	 'probe#':4,
	 'on_probe#':5,
	 'clusterIdx':6,
	 'gain_/loss_score':7,
	 'cluster_score':8,
	 'gain_/loss_sample#':9,
	 'sample_score':10,
	 'sample_ID':11,
	 'CNV_event_ID':12,
	 'CNVR_ID':13}

    @staticmethod
    def get_sample_id ( E ): 
	return E[ipn_header.h['sample_ID']]

    @staticmethod
    def get_cnv_type ( E ):
	return E[ipn_header.h['CNV_type']]

    @staticmethod
    def get_cnv_chr (E):
	return E[ipn_header.h['chr']]

    @staticmethod
    def get_cnv_start (E):
	return E[ipn_header.h['start']]

    @staticmethod
    def get_cnv_end (E):
	return E[ipn_header.h['end']]
    
    @staticmethod
    def get_all_probe_num (E):
	return E[ipn_header.h['probe#']]

    @staticmethod
    def get_on_probe_num (E):
	return E[ipn_header.h['on_probe#']]

    @staticmethod
    def get_sample_id_idx ():
	return ipn_header.h['sample_ID']
# ------------------------------------------------------------------------ |

# specially for directory
def check_or_make_dir ( fname ):
    if ( not os.path.exists ( fname ) ):
        os.mkdir ( fname )

    # check for the second time, in case we cannot make the directory
    check_or_exit( fname )
# -------------------------------------------------------------------|

# check if the file exist, or the program quits, this is just for
# backward compatibility, use check_or_make_dir
def check_or_make ( fname ):
    if ( not os.path.exists ( fname ) ):
        os.mkdir ( fname )

    # check for the second time, in case we cannot make the directory
    check_or_exit( fname )
# -------------------------------------------------------------------|

# check if the file exist, or the program quits, this is just for
# backward compatibility, use check_or_make_dir
def check_or_exit ( fname ):
    '''Given a file name check if the file exists.'''
    if ( not os.path.exists(fname) ):
        print >> sys.stderr, fname, ' does not exist.'
        sys.exit(1)
# -------------------------------------------------------------------|

def myglob ( dirname, pattern, use_full_name=False ):
    '''Given a directory name, find all the files that match pattern.
       User has the option of getting the full path name.'''
    import re
    from os import listdir

    files = os.listdir ( dirname )
    results = [ ]

    myre=re.compile (pattern)

    for fname in files:
        if ( myre.search (fname) ):
            if ( use_full_name ):
                results.append ( os.path.join (dirname, fname) )
            else:
                results.append ( fname )

    return results
# -------------------------------------------------------------------------- |

def relink (srcname, dstname):                                                  
    '''Symbolic link a file, delete the link if it exists, then link.'''
    srcname = os.path.abspath ( srcname )
    dstname = os.path.abspath ( dstname )

    if ( os.path.exists(dstname) or os.path.islink (dstname) ):
        if ( os.path.islink (dstname) ):
            os.system ( 'unlink ' + dstname)
        else:
            print >> sys.stderr, '"'+srcname+'"', \
                            'is not a link name, but duplicated.'
            return False

    os.symlink (srcname, dstname)
    return True
# ----------------------------------------------------------------------- |

def check_or_make_file (fname):                                                 
    if ( not os.path.exists (fname) ):
            os.system ( 'touch ' + fname )

    return fname
# ----------------------------------------------------------------------- |

def get_apt_command (cdf_file, dest_dir, cell_file_list):
    apt_cmd=get_command('apt-probeset-summarize')

    cmd= [apt_cmd,  
	  '--cdf-file', cdf_file, 
	  '--analysis', 
	  'quant-norm.sketch=100000.usepm=true.bioc=true,pm-sum,median,expr.genotype=true.allele-a=true', 
	  '--out-dir', 
	  dest_dir, 
	  '--cel-files', 
	  cell_file_list]

    return ' '.join (cmd)
# ----------------------------------------------------------------------- |

