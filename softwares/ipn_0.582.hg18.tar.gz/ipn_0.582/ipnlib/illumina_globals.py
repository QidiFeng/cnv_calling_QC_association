import os, re, sys
import ipn_util

'''
CHANGELOG:
	08-25-11) use batch file name to create key for the batch run
'''

# define all global variables we need
class Globals:
    # this usually does not change
    #temp_prefix = '/hpf/swscherer_projects1/zwang/ipattern_temp/'
    #dest_prefix = '/hpf/swscherer_projects1/zwang/ipattern_data/'
    #call_prefix = '/hpf/swscherer_projects1/zwang/ipattern_results/'
    temp_prefix = '.'
    dest_prefix = '.'
    call_prefix = '.'

    # intermediate and final output file names
    index_file      = 'index.txt'
    probe_file      = 'probes.txt'
    sorted_probes   = 'sorted_probes.txt'
    sample_file     = 'sample_list.txt'
    all_sample_file = 'all_samples.txt'
    match_file      = 'matchfile.txt'

    # final output file
    stat_file       = 'sample.stats.txt'

    # file suffix, used by each step
    sample_file_suffix = 'zzz'
    sort_suffix        = 'sort'
    balanced_suffix    = 'bln'
    normalized_suffix  = 'nml'
    rescale_suffix     = 'rescale'
    vn_suffix          = 'vn'
    chr_suffix         = 'int'

    # short link names
    link_tempdir = 't'
    link_destdir = 'd'

    def __init__ (self, exp_signature, bad_sample_file, gender_file, 
						srcfiles, link_short = True):

        # the following four lines are generally needed changing
        self.exp_signature   = exp_signature
        self.bad_sample_file = bad_sample_file
        self.gender_file     = gender_file
        self.srcfiles        = srcfiles

	# stores everything from the run under current directory, everything
	# will be under this directory
        self.inter_dir= self.exp_signature+'_dir' 

        # create directory for storing every thing
        self.temp_dir = os.path.join (Globals.temp_prefix, 
						self.exp_signature+'_temp' )
        self.dest_dir = os.path.join (Globals.dest_prefix, 
						self.exp_signature+'_chr' )
	self.call_dir = os.path.join (Globals.call_prefix, 
						self.exp_signature+'_call' )

	# intermediate and final files
        self.match_file = os.path.join (self.inter_dir, Globals.match_file)
        self.stat_file  = os.path.join (self.inter_dir, Globals.stat_file)
        self.index_file = os.path.join (self.inter_dir, Globals.index_file)
        self.probe_file = os.path.join (self.inter_dir, Globals.probe_file)
        self.sorted_probes = os.path.join (self.inter_dir, 
							Globals.sorted_probes)
        self.sample_file = os.path.join(self.inter_dir, Globals.sample_file)
        self.all_sample_file = os.path.join (self.inter_dir, 
							Globals.all_sample_file)

        # shortcut to the temporary directories
	if ( link_short ):
	    self.link_tempdir = os.path.join ( self.inter_dir,
						Globals.link_tempdir )
            self.link_destdir  = os.path.join ( self.inter_dir,
						Globals.link_destdir )

        # self test
        ipn_util.check_or_make_file (self.bad_sample_file)

        ipn_util.check_or_make_dir  (self.inter_dir)
        ipn_util.check_or_make_dir  (self.dest_dir)
        ipn_util.check_or_make_dir  (self.temp_dir)
	ipn_util.check_or_make_dir  (self.call_dir)
        ipn_util.check_or_exit ( self.gender_file )
	ipn_util.relink ( self.temp_dir, self.link_tempdir )
	ipn_util.relink ( self.dest_dir, self.link_destdir )

        self.link_all_src_files ( )
    # --------------------

    def link_all_src_files (self):
        for afile in self.srcfiles:
            lnk_nm = os.path.basename (afile)
            lnk_nm = os.path.join ( self.inter_dir, lnk_nm )
            ipn_util.relink (afile, lnk_nm)
    # --------------------

    # desctructor
    def __del__ (self):
	for afile in self.srcfiles:
            lnk_nm = os.path.basename (afile)
	    lnk_nm = os.path.join ( self.inter_dir, lnk_nm )

	    if os.path.exists(lnk_nm): os.unlink (lnk_nm)
# --------------------------------------------------------------------------|

# batch information, run each batch
class Batch (Globals):
    '''
    Contains batch information needed to preprocess data.
    The information of the whole data set is held in g, thus you must
    create a Globals object first.

    A batch shares some information of global data set, such
    as bad_sample_file, gender information and source files.
    '''

    @staticmethod 
    def change_names_in_batch (outfile, infile):
	inf = open (infile)
	outf= open (outfile, 'w')
	for line in inf:
	    nm =ipn_util.change_name (line.rstrip('\n'))
	    print >> outf, nm
	outf.close()
	inf.close()
    # ------------

    def __init__ (self, batch_file, g):
	# use batch file name as a key
        sig = os.path.basename ( batch_file )

        # call base constructor
        Globals.__init__ (self, sig, g.bad_sample_file, 
					g.gender_file, g.srcfiles, True)

        #self.all_sample_file = batch_file
        Batch.change_names_in_batch (self.all_sample_file, batch_file)

        # shortcut to the temporary directories, save input characters
        self.link_tempdir = sig+'_t'
        self.link_destdir = sig+'_d'

        ipn_util.check_or_exit (self.gender_file)
        ipn_util.check_or_exit (self.all_sample_file)

        # self test
        ipn_util.check_or_make_file (self.bad_sample_file)

        ipn_util.check_or_make_dir (self.inter_dir)
        ipn_util.check_or_make_dir (self.dest_dir)
        ipn_util.check_or_make_dir (self.temp_dir)
	ipn_util.check_or_make_dir (self.call_dir)

        ipn_util.relink (self.temp_dir, self.link_tempdir)
        ipn_util.relink (self.dest_dir, self.link_destdir)
    # ------------

    def __del__(self):
	Globals.__del__ (self)
# Batches ends here
# ----------------------------------------------------------------------|
