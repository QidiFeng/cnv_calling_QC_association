import re, os, sys
import subprocess
import xml.dom.minidom
import time

class JobInfo:
	def __init__ (self, job_num=None, jat_prio=None, 
			    jb_name=None, jb_owner=None, 
			    jb_state=None, jb_start_time=None, 
			    qname=None, slots=1, tasks=1):
		self.job_num=job_num
		self.job_priority=jat_prio
		self.job_name=jb_name
		self.job_owner=jb_owner
		self.job_state=jb_state
		self.job_start_time=jb_start_time
		self.job_qname=qname
		self.job_slots=slots
		self.job_tasks=tasks

	def __str__ (self):
		return '|'.join ([str(self.job_num),
				  str(self.job_priority),
				  str(self.job_name),
				  str(self.job_owner),
				  str(self.job_state),
				  str(self.job_start_time),
				  str(self.job_qname),
				  str(self.job_slots),
				  str(self.job_tasks)])
# ------------------------------------------------------------- |


def get_qstat_xml_str ( ):
	'''
	In case there is server is not available, we wait for 5 minutes;
	then we spill out the error message
	'''
	#cmd=["qstat", "-u", "`whoami`", "-xml"]
	cmd=["qstat", "-x"]
	stdout_str=""
	stderr_str=""

	repeat = 1
	while True:
		try:
			p=subprocess.Popen (' '.join(cmd), 
					    shell=True,
					    stdout=subprocess.PIPE,
					    stderr=subprocess.PIPE)
			stdout_str, stderr_str=p.communicate()

		except OSError, detail:
			if repeat < 5:
				repeat += 1
				time.sleep(60)
			raise detail
		except ValueError, e:
			raise e

		break

	return stdout_str
# ------------------------------------------------------------- |

def handle_job_queue ( job_queue ):
	#jobs=job_queue.getElementsByTagName ("job_list")
	jobs=job_queue.getElementsByTagName ("Job")
	jobs=handleToc ( jobs )

	return jobs
# ------------------------------------------------------------- |

def getText(nodelist):
	rc = []
	for node in nodelist:
	        if node.nodeType == node.TEXT_NODE:
			rc.append(node.data)
	return ''.join(rc)
# ------------------------------------------------------------- |

def handleToc (jobs):
	all_jobs={}

	for jb in jobs:

		node=jb.getElementsByTagName ("job_state")[0]
		job_state=getText(node.childNodes)

		if job_state == 'C': continue

		node=jb.getElementsByTagName ("Job_Owner")[0]
		job_owner=getText(node.childNodes)

		if not re.search ('zwang', job_owner): continue

		ajob=JobInfo ( )
		node=jb.getElementsByTagName ("Job_Id")[0]
		ajob.job_num=getText (node.childNodes)

		node=jb.getElementsByTagName ("Priority")[0]
		ajob.job_priority=getText(node.childNodes)

		node=jb.getElementsByTagName ("Job_Name")[0]
		ajob.job_name=getText(node.childNodes)


		node=jb.getElementsByTagName ("job_state")[0]
		ajob.job_state=getText(node.childNodes)

		if ajob.job_state == 'R':
			node=jb.getElementsByTagName ("start_time")
			ajob.job_start_time=getText(node)

			node=jb.getElementsByTagName ("queue")[0]
			ajob.job_qname=getText(node.childNodes)

			#node=jb.getElementsByTagName ("slots")[0]
			#ajob.job_slots=getText(node.childNodes)

			#node=jb.getElementsByTagName ("tasks")

			#if len(node) != 0:
			#	node=node[0]
			#	ajob.job_tasks=getText(node.childNodes)

		all_jobs[ajob.job_num]=ajob

	return all_jobs
# --------------------------------------------------------------------------- |

# get myjobs in a dictionary, with keys are the job id
def get_myjobs ():
	jobs={}

	job_xml_str=get_qstat_xml_str ()

	if job_xml_str == "": return jobs

	dom=xml.dom.minidom.parseString(job_xml_str)
	jobs=handle_job_queue (dom)

	return jobs
# -------------------------------------------------------------------------|
