# define a class to describe probe information and 
# map string chromosomes to numeric values

class MapChr:
    ''' Z is the end marker, used to add more data. '''

    def __init__ (self):
	# Key 'Z' is a sentry
	self.hh = { '0':0, '00':0, 'chr0':0, 'chr00':0,
		    '1':1, '01':1, 'chr1':1, 'chr01':1,
		    '2':2, '02':2, 'chr2':2, 'chr02':2,
		    '3':3, '03':3, 'chr3':3, 'chr03':3,
		    '4':4, '04':4, 'chr4':4, 'chr04':4,
		    '5':5, '05':5, 'chr5':5, 'chr05':5,
		    '6':6, '06':6, 'chr6':6, 'chr06':6,
		    '7':7, '07':7, 'chr7':7, 'chr07':7,
		    '8':8, '08':8, 'chr8':8, 'chr08':8,
		    '9':9, '09':9, 'chr9':9, 'chr09':9,
		    '10':10, 'chr10':10,
		    '11':11, 'chr11':11,
		    '12':12, 'chr12':12,
		    '13':13, 'chr13':13,
		    '14':14, 'chr14':14,
		    '15':15, 'chr15':15,
		    '16':16, 'chr16':16,
		    '17':17, 'chr17':17,
		    '18':18, 'chr18':18,
		    '19':19, 'chr19':19,
		    '20':20, 'chr20':20,
		    '21':21, 'chr21':21,
		    '22':22, 'chr22':22,
		    '23':23, 'chr23':23,
		    '24':24, 'chr24':24,
		    'X':23,  'chrX':23,
		    'Y':24,  'chrY':24,
		    'M':25,  'Mt':25, 'mt':25, 'MT':25, 'chrM':25, 'chrMT':25,
                    'Z':26 }

	self.h = ['chr00',
		  'chr01', 'chr02', 'chr03', 'chr04', 'chr05', 
		  'chr06', 'chr07', 'chr08', 'chr09', 'chr10',
		  'chr11', 'chr12', 'chr13', 'chr14', 'chr15',
		  'chr16', 'chr17', 'chr18', 'chr19', 'chr20',
		  'chr21', 'chr22', 'chrX',  'chrY',  'chrM']

	self.hN =['0',
		  '1',  '2',  '3',  '4',  '5',  '6',  '7',  '8',  '9',  '10',
		  '11', '12', '13', '14', '15', '16', '17', '18', '19', '20',
		  '21', '22', 'X',  'Y',  'MT']
    # ------------------------------------------------------------------ |

    def has_key (self, key):
	    return self.hh.has_key(key)

    def __getitem__ (self, key):
        try:
                return self.hh[key]
        except KeyError:
		# enlarge the hash table
                self.hh[key] = self.hh['Z']
                self.hh['Z'] = self.hh['Z']+1
		self.h.append  (key)
		self.hN.append (key)

        return self.hh[key]
    # ------------------------------------------------------------------ |

    # return choromosome with 'chr'
    def getchr (self, idx):
	return self.h[idx]
    # ------------------------------------------------------------------ |

    # return with a single number or character
    def getchrN (self, idx):
        if type(idx).__name__ == 'int': return self.hN[idx]
	else: return idx
# --------------------------------------------------------------------- |

class Probe:
    ''' 
    Chromosome number and position are integer in a probe object.
    '''
    @staticmethod
    def cmp_pos (a, b):
	if a.pos == b.pos: return a.end - b.end

        return a.pos - b.pos
    # ------------------------------------------------------------------ |
    @staticmethod
    def cmp_chrom(x, y):
	return MyMap[x] - MyMap[y]

    @staticmethod
    def comp ( a, b ):
        if a.chr == b.chr: return cmp_pos(a,b)

        return MyMap[a.chr] - MyMap[b.chr]
    # ------------------------------------------------------------------ |

    def __init__ ( self, name = None, chrom=-1, pos=-1, end=-1 ):
        self.name = name
        self.chr  = MyMap[chrom]
        self.pos  = pos

	if end == -1: self.end  = pos
	else: self.end = end
    # ------------------------------------------------------------------ |

    def getline ( self, sep='\t' ):
	return sep.join([self.name, 
			 str(MyMap.getchrN(self.chr)),
			 str(self.pos)])
# -----------------------------------------------------------------------|

# read a probe file in 3 column, and return the probes hashed by chromsome
# all chromsomes are based on text, note we do not sort the probes
def read_hash_probe_file ( fname ):
    h = { }

    f = open (fname )
    for line in f:
	E = line.rstrip ('\n').split()

	if ( not h.has_key(E[1]) ): h[E[1]] = [ ]

	h[E[1]].append ( Probe (E[0], MyMap[E[1]], int(E[2])) )

    f.close()
    return h
# -----------------------------------------------------------------------|

MyMap = MapChr ()
ChrMapper = MyMap
