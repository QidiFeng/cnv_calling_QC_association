'''
Functions in this file return a string containing parameters of other program,
users may want to change the parameters calling the program.
'''

apt_cmd = "apt-probeset-summarize"

def get_apt_command (cdf_file, dest_dir, cell_file_list):
    cmd= [apt_cmd,  
	  '--cdf-file', cdf_file, 
	  '--analysis', 
	  'quant-norm.sketch=100000.usepm=true.bioc=true,pm-sum,median,expr.genotype=true.allele-a=true', 
	  '--out-dir', 
	  dest_dir, 
	  '--cel-files', 
	  cell_file_list]

    return cmd
# ----------------------------------------------------------------------- |
