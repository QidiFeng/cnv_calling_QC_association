# define variables and procedures of splitting files into PennCNV format
import re, os, sys
import ipn_util

# Return what is wrong with the data file
class MissColmnException (Exception):
    def __init__ (self, name):
        self.name = name
    def __str__ (self):
        return "Missing column %s in the data file"
# ---------------------------------------------------------------- |


class IPNFormat:
    # column names that we need to use, we use exec to assign the proper
    # index of the columns
    needed = {'Sample ID':'self.sample_id',
              'Log R Ratio':'self.logrr',
              'Chr':'self.chr',
              'SNP Name':'self.snp_name',
              'Position':'self.position',
              'Allele1 - Forward':'self.af1',
              'Allele2 - Forward':'self.af2',
              'X':'self.X',
              'Y':'self.Y'}
    # ---------------------------------------------------------------- |

    top_allele={ 'Allele1 - Top':'self.af1',
                 'Allele2 - Top':'self.af2' }

    # Given a set of indices, we return a string in PENNCNV FORMAT
    def check_column_index (self):
        # error checking
        for k, v in IPNFormat.needed.iteritems():
            exec "flag=%s is None" % (v)

            if ( flag ):
                if (k=='Position' or k == 'Chr'): 
                    if self.all_probes is None: 
                        ipn_util.error ('This file NEEDs probe annotation file.')
                    else:
                        continue

                raise MissColumnException (k)
    # --------------------------------------------------------------------- |

    @staticmethod
    def penn_header (sample_name):
        return '\t'.join ( ['Name', 
                            'Chr', 
                            'Position',
                            '.'.join ([sample_name, 'GType']),
                            '.'.join ([sample_name, 'Log R Ratio']),
                            '.'.join ([sample_name, 'B Allele Freq']) ] )
    # --------------------------------------------------------------------- |

    def __init__ (self, reffile, all_probes=None):
        # These are the variables used for generating Ipattern format
        self.sample_id = None
        self.snp_name  = None
        self.chr       = None
        self.position  = None
        self.logrr     = None
        self.baf       = None
        self.af1       = None
        self.af2       = None

        # Necessary information we need from the file
        self.allele1   = None
        self.allele2   = None
        self.X         = None
        self.Y         = None

        # character used to separate elements in a line
        self.sep_char  = '\t'

        self.all_probes= all_probes
        self.reffile   = reffile

        self.determine_col_index ()
    # ---------------------------------------------------------------- |

    # given a file name, determine the needed columns' indices
    def determine_col_index (self):
        f = open (self.reffile)

        while True:
                line = f.readline()
                if ( re.search ('Sample ID', line) ): break
        f.close()

        header_line=line

        # so far we only recognize two separation character, ',' or '\t'
        if re.search (',', header_line): self.sep_char=','

        headers=header_line.rstrip('\r\n').split (self.sep_char)

        for i, E in enumerate(headers):
            if IPNFormat.needed.has_key(E):
                exec IPNFormat.needed[E]+'='+'int('+str(i)+')'

        if self.af1 is None:
            for i, E in enumerate(headers):
                if IPNFormat.top_allele.has_key(E):
                    exec IPNFormat.top_allele[E]+'='+'int('+str(i)+')'

        self.check_column_index ()

        if self.af1 is not None: self.allele1 = self.af1
        if self.af2 is not None: self.allele2 = self.af2

        self.printall()
    # ---------------------------------------------------------------- 

    def format_line (self, E):
        usedchr=usedpos=None

        use_annotation=False # use the probe information in the given file

        flag=False

        # determine where the probe information comes from
        if self.all_probes is not None:
            if self.all_probes.has_key (E[self.snp_name]):
                if self.chr is None: use_annotation=True
            else:
                return None
        
        if use_annotation:
                usedchr=self.all_probes[E[self.snp_name]].chr
                usedpos=self.all_probes[E[self.snp_name]].pos
        else:
                usedchr=E[self.chr]
                usedpos=E[self.position]

        return "%s\t%s\t%s\t%s\t%s" % \
                ( E[self.snp_name],
                  #myprobe.MyMap.getchrN(usedchr),
                  #usedpos,
                  E[self.allele1]+E[self.allele2],
                  E[self.logrr],
                  E[self.X],
                  E[self.Y] )
    # ---------------------------------------------------------------- 

    def split (self, line):
        return line.rstrip ('\r\n').split(self.sep_char)
    # ---------------------------------------------------------------- 

    # used for debugging
    def printall (self):
        myprint ('sample_id', self.sample_id)
        myprint ('snp_name',  self.snp_name)
        myprint ('chr',       self.chr )
        myprint ('position',  self.position)
        myprint ('allele1',   self.allele1)
        myprint ('allele2',   self.allele2)
        myprint ('logrr',     self.logrr)
        myprint ('X',         self.X)
        myprint ('Y',         self.Y)
# -------------------------------------------------------------------- 

def myprint (name, val): 
    print "%-10s%5s" % (name, str(val))
