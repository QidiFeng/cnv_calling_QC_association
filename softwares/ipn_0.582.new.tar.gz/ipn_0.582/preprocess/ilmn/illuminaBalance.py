#! /usr/bin/python

import os, re, sys
import ipn_qsub
import ipn_util


tmp_path  = ipn_qsub.qsub_tmp	# temporary path for qout and qerr files
batch_num = 500			# the maximum number of jobs in the queue
Rtempfiles=[]			# record all R output files

Rcmd=os.path.join (ipn_util.get_ipn_Rcode_dir(), 'channelBalancer.R')
R=ipn_util.get_R_interpreter()

def create_Rfiles ( path, key ):
    return ( os.path.join (path, key+'.'+ipn_util.Rout), \
             os.path.join (path, key+'.'+ipn_util.Rerr) )
# ----------------------------------------------------------------|

def remove_Rfiles ( ):
    for a in Rtempfiles:
	if ( os.path.exists(a) ): os.unlink (a)
# ----------------------------------------------------------------|

def genRcmd ( infname, outfname, indirname, outdirname ):
    global Rtempfiles

    Rout, Rerr = create_Rfiles(tmp_path, infname)

    Rtempfiles.append (Rout)
    Rtempfiles.append (Rerr)

    #cmd = ' '.join ( [ '(', R,
    #                   '--no-save', '--no-restore', '--no-readline',
    #                   os.path.join (indirname, infname),
    #                   os.path.join (outdirname, outfname),
    #                   '<', Rcmd,
    #                   '>', Rout, ')', '>&', Rerr] )

    cmd = ' '.join ( [ R,
                       '--no-save', '--no-restore', '--no-readline',
                       os.path.join (indirname, infname),
                       os.path.join (outdirname, outfname),
                       '<', Rcmd,
                       '>', Rout, '2>', Rerr] )

    return cmd
# ----------------------------------------------------------------|

def do_balance (qfile_list):
    # finish the jobs sequentially
    if noqsub:
        for cmd in qfile_list:
	    print >> sys.stderr, cmd

	    ret=os.system ( "bash %s" % (cmd) )

	    if ret != 0:
                print >> sys.stderr, "Channel balancing has error"
		print >> sys.stderr, "command: %s" % (cmd)

		sys.exit(1)

	return

    # do things parallelly
    if ( len(qfile_list) < batch_num ):
        ipn_qsub.run_wait_poll (qfile_list, 300)
    else:
        ipn_qsub.run_with_num (qfile_list, batch_num, 300)

    ret = ipn_qsub.cleanup (qfile_list)

    if ret is not None:
	    print >> sys.stderr, \
		     "ChannelBalancing has problems, check the following files:"
	    print >> sys.stderr, "\n".join(ret)
	    print >> sys.stderr, 'OR FILES:'
	    print >> sys.stderr, '\n'.join ( 
			map(lambda nm: re.sub ( ipn_qsub.__qsub_err_suffix__, 
						ipn_util.Rerr, nm), ret) )
	    sys.exit(1) 
# ----------------------------------------------------------------|


def run ( dirname, sample_file, in_suffix, out_suffix ):
    ipn_util.check_or_exit (sample_file )

    qfile_list = [ ]

    f = open ( sample_file )
    for line in f:
        infile = line.rstrip ('\n')+'.'+in_suffix
        outfile= line.rstrip ('\n')+'.'+out_suffix

        cmd = genRcmd (infile, outfile,  dirname, dirname)

        #print >> sys.stderr, cmd

        qfile = ipn_qsub.write_4G_qsub_file ( infile, cmd )

        qfile_list.append ( qfile )
    f.close()

    do_balance (qfile_list)

    remove_Rfiles ()
# ----------------------------------------------------------------|

#
#
#
# main script starts from here
from optparse import OptionParser
parser = OptionParser ()
parser.add_option ( '-s', '--input-directory', dest='srcdir',
    help='input and output directory' )
parser.add_option ( '-m', '--sample-file', dest='samplefile',
    help='a file contains all sample names' )
parser.add_option ( '-a', '--input-suffix', dest='insuffix',
    help='input file suffix, combined with a sample name, we create an input file')
parser.add_option ( '-b', '--output-suffix', dest='outsuffix',
    help='output file suffix, combined with a sample name, we create an output file')
parser.add_option ( '--noqsub', dest='noqsub',
    default=False, action='store_true',
    help='specify if do not want to submit jobs' )

options, args = parser.parse_args()

ipn_util.check_or_make_dir ( tmp_path )

if (not (options.srcdir and options.samplefile \
		and options.insuffix and options.outsuffix)):
    print >> sys.stderr, 'We need all options.'
    parser.print_help()
    sys.exit(1)

noqsub=options.noqsub
run (options.srcdir, options.samplefile, options.insuffix, options.outsuffix)
