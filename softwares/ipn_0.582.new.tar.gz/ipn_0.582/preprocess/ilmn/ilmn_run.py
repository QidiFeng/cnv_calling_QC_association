#! /usr/bin/env python

import os, re, sys

import ipn_util
import ipn_log

import ipn_qsub

import illumina_globals
#from illumina_globals import Batch

log_dir=ipn_util.get_log_dir()
mysep  =ipn_util.get_mysep  ()
python='python'

'''
Change Log:
1. 03/31/2009: *) This script can run not only a batch, but also a 
		  whole data set
2. 11/24/2009: *) split_all_data_files now ignores comment lines
3. 05/25/2011: *) split_all_data_files is taken out, a separate command
	       *) log mechanism is changed, each command's stderr/stdout 
		  are intercepted, either stored in a file or printed on
		  stderr
4. 05/27/2011: *) class Batch was moved to illumina_globals
	       *) check_error IS obsolete
	       *) split gender is taken out
	       *) constants are taken out
'''

'''
Run preprocessing of ipattern by batches. 
User has the option to run global running stuff, through -s.
User needs to specify the global parameters carefully; as they are
used to identify source files. Espeically, the global experiment
signature input from user should be consistent with each run.
Batch's signature is generatated automatically.
'''

def get_full_path ( path, cmd ):
    return os.path.join (path, cmd)

def split_all_data_files ( g ):
    split_cmd = 'split_all_data_files.py'

    split_cmd = ipn_util.get_ilmn_path(split_cmd)

    cmd = [python,
	   split_cmd,
	   '-f', 		 data_file,
	   '-m',		 g.match_file,
	   '--interdir', 	 g.inter_dir,
	   '--output-directory', g.link_tempdir,
	   '--samplefilesuffix', g.sample_file_suffix,
	   '--samplefile',       g.sample_file,
	   '--allsamplefile',    g.all_sample_file]

    if ref_probe_file is not None: cmd+= [ '-p', ref_probe_file ]
    if noqsub: cmd += [ '--noqsub' ]

    print >> sys.stderr, ' '.join (cmd)

    ret, out, err = ipn_qsub.run_cmd_on_node (cmd)

    mylog.check_log ( ret, 'SPLIT ALL DATA', out, err )
# -------------------------------------------------------------------------- |


# There are two commands in one job.
def generate_and_sort_probes ( g ):
    print >> sys.stderr, 'Processing probes ........' 

    two = [ ]

    split_cmd = 'split_sample_probe.py'
    split_cmd = ipn_util.get_ilmn_path(split_cmd)

    split_cmd_elements= [python,
		    	 split_cmd, 
                         '-i', g.srcfiles[0], 
                         '-b', g.probe_file ]

    if ref_probe_file is not None:
	split_cmd_elements += [ '-p', ref_probe_file ]

    cmd = ' '.join ( split_cmd_elements )

    print >> sys.stderr, cmd

    two.append ( cmd )

    sort_cmd = 'sort_probes.py'
    sort_cmd = ipn_util.get_ilmn_path(sort_cmd)

    sort_cmd_elements = [ python,
		    	  sort_cmd,
			  '-p', g.probe_file, 
                          '-x', g.index_file, 
			  '-o', g.sorted_probes ]

    print >> sys.stderr, ' '.join (sort_cmd_elements)

    two.append ( ' '.join (sort_cmd_elements)  )

    print >> sys.stderr, '\\\n&&\n'.join(two)

    if ( not noqsub ):
        ret = ipn_qsub.run_qsub_cmd ( '&&'.join (two), 'IlmnProbes', 
    							qname=proj_name )
        mylog.check_log ( ret, 'GENERATE AND SORT PROBEs' )
    else:
        ret, out, err = ipn_qsub.run_command (split_cmd_elements, 
			                      noqsub, 
					      'find-probe')
        mylog.check_log ( ret, 'find probe', out, err )


	ret, out, err = ipn_qsub.run_command (sort_cmd_elements, 
			                      noqsub, 
					      'sort-probe')
        mylog.check_log ( ret, 'sort probe', out, err )
# -------------------------------------------------------------------------- |


def sort_all ( g ):
    print >> sys.stderr, "Sorting all the sample's intensity values ........"

    cmd = 'ilmn_sort_all_int.py'
    cmd = ipn_util.get_ilmn_path(cmd)

    sample_file = g.sample_file

    if ( not os.path.exists (sample_file) ):
        sample_file = g.all_sample_file

    cmd = [python,
	   cmd, 
	   '-d', g.link_tempdir, 
	   '-m', sample_file,
           '-a', g.sample_file_suffix, 
	   '-b', g.sort_suffix, 
	   '-x', g.sorted_probes]

    print >> sys.stderr, ' '.join (cmd)

    if noqsub:
    	cmd += ['--noqsub']
    	#ret, out, err = ipn_qsub.run_command (cmd, noqsub, 'sort-all-files')

    ret, out, err = ipn_qsub.run_cmd_on_node (cmd)

    mylog.check_log ( ret, 'SORT ALL INTENSITIES', out, err )
# -----------------------------------------------------------------------|


def balance ( g ):
    print >> sys.stderr, 'Channel Balancing each sample ........'

    cmd = 'illuminaBalance.py'
    cmd = ipn_util.get_ilmn_path(cmd)

    sample_file = None

    if ( os.path.exists(g.sample_file) ):
        sample_file = g.sample_file
    else:
        sample_file = g.all_sample_file

    cmd = [python,
	   cmd, 
	   '-s', g.link_tempdir, 
	   '-m', sample_file,
           '-a', g.sort_suffix, 
	   '-b', g.balanced_suffix] 

    if noqsub: cmd += [ '--noqsub' ]

    print >> sys.stderr, ' '.join (cmd)

    ret, out, err = ipn_qsub.run_cmd_on_node (cmd)
    #ret, out, err = ipn_qsub.run_command (cmd, noqsub, 'channel-balancing')

    mylog.check_log ( ret, 'CHANNEL BLANCING', out, err )
# ---------------------------------------------------------------------------|


def remove_bad ( g ):
    '''
       Regenreate the sample list file, which we will remove all the given
       bad samples.
    '''

    print >> sys.stderr, 'Removing bad sample names ........'
    bad_file = open ( g.bad_sample_file )
    all_file = open ( g.all_sample_file )
    sample_file = open ( g.sample_file, 'w' )

    bad = { }
    for line in bad_file:
        bad[line.rstrip('\n')] = line.rstrip ( '\n' )

    # read file and select used samples
    for line in all_file:
        name = line.rstrip ('\n')
        if ( bad.has_key ( name ) ):
            continue

        print >> sample_file, name

    sample_file.close()
    all_file.close()
    bad_file.close()

    #check_error (mylog, 'remove bad', 0)
    mylog.check_log (0, 'REMOVE BAD SAMPLES')
# ---------------------------------------------------------------------------|


def quantile ( g ):
    print >> sys.stderr, 'Quantile normalization ........'

    cmd = 'quantile.py'
    cmd = ipn_util.get_ilmn_path(cmd)

    cmd = [python,
	   cmd, '-d', g.link_tempdir, 
		'-m', g.sample_file,
		'-a', g.balanced_suffix, 
		'-b', g.normalized_suffix]

    print >> sys.stderr, ' '.join(cmd)

    #ret = ipn_qsub.run_qsub_cmd (cmd, 'quantile', qname=proj_name)
    ret, out, err = ipn_qsub.run_command (cmd, noqsub, 'quantile-normalization')

    mylog.check_log (ret, 'QUANTILE NORMALIZATION', out, err)
# ---------------------------------------------------------------------------|

# used for rescale, sometimes, when the number of files are too big
# we need to do rescale partially
def create_paste_cmd ( g, suffix, init_cmd = 'paste', num=500 ):
    cmd =  [init_cmd]
    all_names = [ ]

    # load all the files in the memory
    f = open ( g.sample_file )
    for name in f:
        all_names.append ( name.rstrip('\n') )
    f.close()

    n = len(all_names) # number of sample names

    # sliding window start and end
    starti = 0
    endi   = 0

    # loop to generate all paste commands
    while True:
        endi = starti + num

        if ( endi > n ): endi = n

        for name in all_names[starti:endi]:
            fname = os.path.join ( g.link_tempdir, \
                               '.'.join ([name, suffix]) )

            cmd.append ( fname )

        # previous output will be used by the following paste command as input
        if ( endi < n ):
            cmd.append ( '|' )
            cmd.append ( 'paste' )
            cmd.append ( '/dev/stdin' )
        else:
            break

        starti = endi

    return ' '.join ( cmd )
# ------------------------------------------------------------------------ |


def rescale ( g ):
    print >> sys.stderr, 'Rescaling intensity values ........'

    scale_cmd = 'rescale.py'
    cmd = ipn_util.get_ilmn_path(scale_cmd)

    cmd = [python,
	   cmd, '-d', g.link_tempdir, 
		'-m', g.sample_file,
		'-a', g.normalized_suffix, 
		'-b', g.rescale_suffix]

    print >> sys.stderr, ' '.join (cmd)

    #ret = ipn_qsub.run_qsub_cmd ( cmd, 'rescale', qname=proj_name )
    ret, out, err=ipn_qsub.run_command (cmd, noqsub, 'rescale')

    mylog.check_log ( ret, 'RESCALE INTENSITIES', out, err )
# -----------------------------------------------------------------------|


def variance ( g ):
    print >> sys.stderr, 'Variance normalization ........'

    # remove old files, so that we will not have mixed results
    if ( os.path.exists ( g.stat_file ) ): os.unlink ( g.stat_file ) 

    cmd = 'variance.py'
    cmd = ipn_util.get_ilmn_path(cmd)

    cmd = [ python,
	    cmd, '-d', g.link_tempdir, 
		 '-m', g.sample_file, 
		 '-a', g.rescale_suffix, 
		 '-b', g.vn_suffix, 
		 '-v', g.stat_file ]

    print >> sys.stderr, ' '.join (cmd)

    #ret = ipn_qsub.run_qsub_cmd ( cmd, 'variance', qname=proj_name )
    ret, out, err = ipn_qsub.run_command ( cmd, noqsub, 'variance' )

    mylog.check_log ( ret, 'VARIANCE NORMALIZATION', out, err )
# -----------------------------------------------------------------------|


def splitChr ( g ):
    '''
    Split the probes according to chromosome, and store them at the 
    intermediate directory; as generally, we do not use them.
    '''

    print >> sys.stderr, 'Splitting chromosomes ........'

    pqfile=ipn_util.get_pqfile()
    cmd = 'split_chr.py'
    cmd = ipn_util.get_ilmn_path(cmd)

    cmd = [python,
	   cmd, '-m', g.sample_file, 
		'-p', g.sorted_probes, 
		'-s', g.link_tempdir, 
		'-d', g.inter_dir, 
		'-x', g.vn_suffix, 
		'-g', g.gender_file, 
		'-q', pqfile,
		'-z', g.exp_signature] 

    print >> sys.stderr, ' '.join (cmd)

    #ret = ipn_qsub.run_qsub_cmd ( cmd, 'splitChr', qname=proj_name )
    ret, out, err = ipn_qsub.run_command (cmd, noqsub, 'splitChr')
    mylog.check_log ( ret, 'SPLIT CHROMOSOME', out, err)
# --------------------------------------------------------------------------- |


def splitByGender ( g ):
    print >> sys.stderr, 'Splitting by gender ........'

    cmd = 'split_by_gender.py'
    cmd = ipn_util.get_ilmn_path(cmd)

    cmd = [python,
	   cmd,
	   '-s', g.inter_dir,
	   '-d', g.inter_dir,
	   '-g', g.gender_file]

    print >> sys.stderr, ' '.join (cmd)

    #ret, out, err = ipn_qsub.run_cmd_on_node (cmd)
    ret, out, err = ipn_qsub.run_command (cmd, noqsub, 'splitChr')

    mylog.check_log (ret, 'SPLIT GENDER', out, err)
# --------------------------------------------------------------------------- |


# mainly, we copy two files: stat file and call file
def copyresults (g):
    print >> sys.stderr, os.getcwd()

    #
    cmd = [ 'cp', 
	    g.stat_file,
	    os.path.join (resultdir, 
			  g.exp_signature+'_'+os.path.basename(g.stat_file))]

    ret, out, err = ipn_qsub.run_cmd_on_node(cmd)
    mylog.check_log (ret, 'COPY STAT FILE "' + g.stat_file +'"', out, err)

    #
    resultfile=os.path.join(g.call_dir,ipn_util.make_ipn_call_file (g.dest_dir, g.exp_signature))
    cmd = [ 'cp', resultfile, resultdir ]

    ret, out, err = ipn_qsub.run_cmd_on_node(cmd)
    mylog.check_log (ret, 'COPY CALL FILE "'+resultfile+'"')
# --------------------------------------------------------------------------- |


# copy files or remove all the temporary files
def cleanup ( g ):
	if not do_cleanup: return

	print >> sys.stderr, "REMOVE INTERMEDIATE directories:"

	print >> sys.stderr, g.inter_dir
	os.system ( "rm -rf %s" % (g.inter_dir) )

	print >> sys.stderr, g.temp_dir
	os.system ( "rm -rf %s" % (g.temp_dir) )

	print >> sys.stderr, g.dest_dir
	os.system ( "rm -rf %s" % (g.dest_dir) )

	print >> sys.stderr, g.call_dir
	os.system ( "rm -rf %s" % (g.call_dir) )

	print >> sys.stderr, ".qsub"
    	os.system ( 'rm -rf .qsub' )

	print >> sys.stderr, '.tmp'
	os.system ( 'rm -rf .tmp' )
# --------------------------------------------------------------------------- |

# used for batch run, we start from the quantile normalization step
def prepare_files ( g, b ):
    # link balance files
    import ipn_util
    sample_names = ipn_util.read_sample_file ( b.sample_file )
    srcdir = g.temp_dir

    for aname in sample_names:
        bln_name= '.'.join ( [aname, g.balanced_suffix] )
        src_nm = os.path.join ( srcdir, bln_name )
        dst_nm = os.path.join ( b.temp_dir, bln_name )
        ipn_util.relink (src_nm, dst_nm)

    # set up links of necessary files
    if ( not os.path.exists ( b.sorted_probes ) ):
        ipn_util.relink ( os.path.abspath(g.sorted_probes), b.sorted_probes ) 

    if ( not os.path.exists ( b.probe_file ) ):
        ipn_util.relink ( os.path.abspath(g.probe_file), b.probe_file )

    if ( not os.path.exists ( b.index_file ) ):
        ipn_util.relink ( os.path.abspath(g.index_file), b.index_file )
# --------------------------------------------------------------------------- |


def movefiles (g):
    from shutil import move 
    intfiles = ipn_util.myglob (g.inter_dir, g.chr_suffix)
    
    for nm in intfiles: 
	tomove = True 

	if not re.search ('^chr1|chr2|chr3|chr4|chr5|chr6|chr7|chr8|chr9', nm ):
	    tomove = False 
	    if re.search ( '^chrX|chrY', nm ):
		if re.search ( 'male', nm ): tomove = True 

	# if not move, we leave it there 
	if not tomove: continue 
	else:
	    print >> sys.stderr, 'MOVING FILE', nm 
	    move (os.path.join(g.inter_dir, nm), 
			    os.path.join(g.link_destdir, nm)) 
# ------------------------------------------------------------------- |


def log_command ( ):
    f = open ( ipn_util.get_log_file(), 'a' )
    print >> f, ' '.join ( sys.argv )
    f.close()
# ------------------------------------------------------------------- |


def run_ipn ( g ):
    #cur_dir = os.getcwd ()

    ipn_cmd = 'run_ipattern.py'
    ipn_dir = ipn_util.get_ipn_path()
    ipn_cmd = os.path.join (ipn_dir, ipn_cmd)

    cmd = [ python,
	    ipn_cmd, 
	    '-s', os.path.abspath(g.dest_dir),
	    '-t', os.path.abspath(g.call_dir) ]

    if noqsub: cmd += ['--noqsub']

    print >> sys.stderr, ' '.join (cmd)

    #ret=os.chdir ( ipn_dir )
    #mylog.check_log ( ret, 'CHANGE TO DIRECTORY %s' %(ipn_dir) )

    ret, out, err = ipn_qsub.run_cmd_on_node (cmd)

    msg='IPATTERN ANALYSIS FINISHED SUCCESSFULLY, RESULTS ARE UNDER %s.' \
								% (g.call_dir) 

    if ret != 0: 
	msg='RUNNING IPATTERN HAS PROBLEM, CHECK DIRECTORY %s.' %  (g.call_dir)

    mylog.check_log (ret, 'IPATTERN-ANALYSIS', out, err)

    #os.chdir (cur_dir)
# ----------------------------------------------------------------- |

# the main engine of the script
def run ( g ):
    # before everything starts, we log what we are running.
    # log_command ( )

    split_all_data_files ( g )
    generate_and_sort_probes ( g )
    sort_all(g)
    balance (g)

    remove_bad ( g )

    quantile(g)
    rescale (g)
    variance(g)
    splitChr(g)
    splitByGender (g)
    movefiles(g)

    run_ipn (g)

    copyresults(g)
    cleanup (g)
# ----------------------------------------------------------------------- |

#
#
#
# main starts from here
from optparse import OptionParser

parser = OptionParser ( )
parser.add_option ( '-g', '--gender-file', dest='gender_file',
	help = 'gender file name, one sample per line, format: ' + \
				'NAME F(female) or M(male)' )
   
parser.add_option ( '-m', '--bad-sample-file',  dest='bad_names',
	help= 'a file contains all the bad sample names which will '+\
				'be excluded from analysis')

parser.add_option ( '-f', '--data-file-list', dest='data_files',
	help= 'a file contains all the data file names, '+\
				'which are generated by other software' )

#parser.add_option ( '-b', '--batch-file', dest='batch_file', 
#    	help= 'batch file, a subset of sample names used for analysis' )

parser.add_option ( '-x', '--experiment', dest='experiment',
	help= 'a unique experiment signature used to generate names' )

parser.add_option ( '-p', '--probe-file', dest='probefile',
	help='probe coordinate file name, for some data set we ' + \
				'have a separate probe information file' )

parser.add_option ( '-o', '--output-directory', dest='outdir',
	default='.',
	help='directory where we need to copy the call/stat files.' )

#parser.add_option ( '--split-file', dest='do_global_split',
#	default = False, action='store_true',
#	help='used with -b, indicating if we need to call '+\
#			      'split process or channel balance' )

parser.add_option ( '--do-log', dest='dolog',
	default = False, action='store_true',
	help='specify if we use physical file to log message, or on stderr' )

parser.add_option ( '--do-cleanup', dest='cleanup',
	default = False, action='store_true',
	help='specify if we clean up all the temporary files' )
parser.add_option ( '--noqsub', dest='noqsub',
	default=False, action='store_true',
	help='specify if you do not want to submit a job' )

parser.add_option ( '--temp-prefix-directory-name', dest='tempprefix',
	                help='the prefix of temporary directory' )
parser.add_option ( '--dest-prefix-directory-name', dest='destprefix',
	                help='the prefix of temporary directory' )
parser.add_option ( '--call-prefix-directory-name', dest='callprefix',
	                help='the prefix of the ipattern call directory' )


options, args = parser.parse_args()

if ( (len(args) == 1) or (not options.experiment)\
		or (not options.gender_file) or (not options.bad_names) \
						or (not options.data_files) ): 
	parser.print_help ()
	sys.exit(1)

# if batch_file is not specified, we run global only
#if ( not options.batch_file ): 
#	print >> sys.stderr, 'NOTE RUN GLOBAL ONLY.'

expsig          = options.experiment
bad_file        = options.bad_names
resultdir       = options.outdir
data_file       = options.data_files
#batch_file      = options.batch_file
gender_file     = options.gender_file
ref_probe_file  = options.probefile

do_cleanup      = options.cleanup
noqsub          = options.noqsub
#do_global_split = options.do_global_split

#run_global  = (batch_file is None)

if options.destprefix: 
	ipn_util.check_or_make_dir (options.destprefix)
	illumina_globals.Globals.dest_prefix = options.destprefix
if options.tempprefix: 
	ipn_util.check_or_make_dir (options.tempprefix)
	illumina_globals.Globals.temp_prefix = options.tempprefix
if options.callprefix: 
	ipn_util.check_or_make_dir (options.callprefix)
	illumina_globals.Globals.call_prefix = options.callprefix

data_file_list = ipn_util.read_sample_file (data_file, False)
proj_name=os.getenv (ipn_util.proj_name_env)


# create a global information, used for all batches 
g = illumina_globals.Globals (expsig, bad_file, gender_file, data_file_list)


# prepare the needed files
ipn_util.check_or_make_dir (log_dir)
ipn_util.check_or_make_dir (resultdir)

log_stderr_file='/dev/stderr'
log_stdout_file='/dev/stdout'
if options.dolog:
	log_stderr_file=os.path.join (expsig + '.stderr')
	log_stdout_file=os.path.join (expsig + '.stdout')

	print 'USE LOG FILES'
	print log_stderr_file
	print log_stdout_file

mylog = ipn_log.MyLog(log_stderr_file, log_stdout_file)

run (g)

print 'iPattern Analysis finished SUCCESSFULLY.'
